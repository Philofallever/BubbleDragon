--
-- Author: songtianming
-- Date: 2017-01-07 11:41:05
-- File: customBtNodes.lua
local nodes = {
    ActionLoading = require("app.newFight.BTNodeFight.ActionLoading"),
    ActionBossWarning = require("app.newFight.BTNodeFight.ActionBossWarning"),
    ActionPlayOneStory = require("app.newFight.BTNodeFight.ActionPlayOneStory"),
    ActionPlayOneAction = require("app.newFight.BTNodeFight.ActionPlayOneAction"),
}

return nodes
